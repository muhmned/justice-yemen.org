import * as AlloyParts from '../../parts/AlloyParts';
import * as PartType from '../../parts/PartType';
// TODO: ^ rename the parts/ api to composites, it will break mobile alloy now if we do

const parts = AlloyParts;
const partType = PartType;

export {
  parts,
  partType
};