import { createFile, createFileFromString, getFileDataAsString } from '../file/Files';

export {
  createFile,
  createFileFromString,
  getFileDataAsString
};
